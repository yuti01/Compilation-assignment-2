#include "Token.h"

/* This package describes the storage of tokens identified in the input text.
* The storage is a bi-directional list of nodes.
* Each node is an array of tokens; the size of this array is defined as TOKEN_ARRAY_SIZE.
* Such data structure supports an efficient way to manipulate tokens.

There are three functions providing an external access to the storage:
- function create_and_store_tokens ; it is called by the lexical analyzer when it identifies a legal token in the input text.
- functions next_token and back_token; they are called by parser during the syntax analysis (the second stage of compilation)
*/

int currentIndex = 0;
Node* currentNode = NULL;

int backStepsCounter = 0;

#define TOKEN_ARRAY_SIZE 1000

/*
* This function creates a token and stores it in the storage.
*/
void create_and_store_token(eTOKENS kind, char* lexeme, int numOfLine)
{
	int length = strlen(lexeme) + 1;

	// case 1: there is still no tokens in the storage.
	if (currentNode == NULL)
	{
		currentNode = (Node*)malloc(sizeof(Node));

		if (currentNode == NULL)
		{
			fprintf(yyout, "\nUnable to allocate memory! \n");
			exit(0);
		}
		currentNode->tokensArray =
			(Token*)calloc(sizeof(Token), TOKEN_ARRAY_SIZE);
		if (currentNode->tokensArray == NULL)
		{
			fprintf(yyout, "\nUnable to allocate memory! \n");
			exit(0);
		}
		currentNode->prev = NULL;
		currentNode->next = NULL;
	}

	// case 2: at least one token exsits in the storage.
	else
	{
		// the array (the current node) is full, need to allocate a new node
		if (currentIndex == TOKEN_ARRAY_SIZE - 1)
		{
			currentIndex = 0;
			currentNode->next = (Node*)malloc(sizeof(Node));

			if (currentNode == NULL)
			{
				fprintf(yyout, "\nUnable to allocate memory! \n");
				exit(0);
			}
			currentNode->next->prev = currentNode;
			currentNode = currentNode->next;
			currentNode->tokensArray =
				(Token*)calloc(sizeof(Token), TOKEN_ARRAY_SIZE);

			if (currentNode->tokensArray == NULL)
			{
				fprintf(yyout, "\nUnable to allocate memory! \n");
				exit(0);
			}
			currentNode->next = NULL;
		}

		// the array (the current node) is not full
		else
		{
			currentIndex++;
		}
	}

	currentNode->tokensArray[currentIndex].kind = kind;
	currentNode->tokensArray[currentIndex].lineNumber = numOfLine;

	currentNode->tokensArray[currentIndex].lexeme = (char*)malloc(sizeof(char) * length);
#ifdef _WIN32
	strcpy_s(currentNode->tokensArray[currentIndex].lexeme, length, lexeme);
#else
	strcpy(currentNode->tokensArray[currentIndex].lexeme, lexeme);
#endif		
}

/*
* This function returns the token in the storage that is stored immediately before the current token (if exsits).
*/
Token* back_token() 
{ 
	// If the current Node is NULL we cant work normally - probably we are calling back_token without calling next_token
	if (currentNode == NULL)
	{
		return NULL;
	}

	// If the current index is 0 - the first cell - we need to go back to the prev Node
	// it is possible only if the prev Node is not NULL
	if (currentIndex == 0)
	{
		if (currentNode->prev == NULL)
		{
			return NULL;
		}
		else
		{
			// inc the back step counter
			backStepsCounter++;

			// Go back to the prev Node
			currentNode = currentNode->prev;
			currentIndex = TOKEN_ARRAY_SIZE - 1; // the current index is pointing to the last cell of the prev Node

			return &currentNode->tokensArray[currentIndex]; // return the Token
		}
	}
	else
	{
		// inc the back step counter
		backStepsCounter++;

		// We are somewhere inside the current Node - go back one cell
		currentIndex--;
		return &currentNode->tokensArray[currentIndex];
	}

	// return ERROR_tok; // unreachable code
}

/*
* If the next token already exists in the storage (this happens when back_token was called before this call to next_token):
*  this function returns the next stored token.
* Else: continues to read the input file in order to identify, create and store a new token (using yylex function);
*  returns the token that was created.
*/
Token* next_token()
{
	if (currentNode == NULL) // probably means we are trying to get the first Token
	{
		// run yylex to get a Token
		yylex();

		return &currentNode->tokensArray[currentIndex]; // return the Token we got
	}

	// the current Node is not NULL
	// Check if we used back_token - if so we will return the next Token without calling yylex() 
	if (backStepsCounter > 0)
	{
		// if the current index is the last one - move to the next node
		if (currentIndex == TOKEN_ARRAY_SIZE - 1)
		{
			currentNode = currentNode->next;
			currentIndex = 0;
			backStepsCounter--; // decrease backStepsCounter

			return &currentNode->tokensArray[currentIndex]; // return the first Token of the next Node
		}
		else
		{
			// the current index is not the last one of this Node
			currentIndex++; // inc the index
			backStepsCounter--; // decrease backStepsCounter

			return &currentNode->tokensArray[currentIndex]; // return the first Token of the next Node
		}

	}

	// We need to call to yylex - the next Token is not saved in the data structure
	yylex();

	return &currentNode->tokensArray[currentIndex];
}

/* 
	move to the next Token and check if its kind is the same as the given Token's kind 
*/
void match(eTOKENS kindToMatch)
{
	Token* t = next_token(); // get the next token

	// if it is not the same - there is an error
	if (t->kind != kindToMatch)
	{
		// printing error message
		fprintf(yysynout, "Expected token of type '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
			, getTokenName(kindToMatch), t->lineNumber, getTokenName(t->kind), t->lexeme);
	}

	// else - everything is fine
}

// Get the token numOfSteps ahead
Token* lookahead(int numOfSteps)
{
	int i; // index for the for loop
	int stepsTaken = 0; // to manage failure 
	Token* theTokenToReturn;

	// run the steps forward (minus 1 step) - stop if you have reached EOF
	for (i = 0; i < numOfSteps - 1 && &currentNode->tokensArray[currentIndex].kind != EOF_tok; i++)
	{
		next_token();
		stepsTaken++;
	}

	// reached EOF before finishing to walk all the steps - return NULL
	if (&currentNode->tokensArray[currentIndex].kind == EOF_tok)
	{
		// we need to go back less than numOfSteps 
		for (; stepsTaken > 0; stepsTaken--)
		{
			back_token();
		}
		return NULL;
	}

	theTokenToReturn = next_token();

	// go back to the start
	for (i = 0; i < numOfSteps; i++)
	{
		back_token();
	}

	return theTokenToReturn;
}

eTOKENS whatIsComingFirst(eTOKENS firstToken, eTOKENS secondToken)
{
	int stepsTaken = 0; // tracks the steps we steped forward

	// while we have not reached on of the given Token or EOF keep going to the next Token
	while (currentNode->tokensArray[currentIndex].kind != firstToken &&
		   currentNode->tokensArray[currentIndex].kind != secondToken &&
		   currentNode->tokensArray[currentIndex].kind != EOF_tok)
	{
		next_token();
		stepsTaken++;
	}

	// if we have reached EOF but it was not our goal - return ERROR_tok
	if (firstToken != EOF_tok && secondToken != EOF_tok && currentNode->tokensArray[currentIndex].kind == EOF_tok)
	{
		while (stepsTaken > 0) // go back
		{
			stepsTaken--;
			back_token();
		}

		return ERROR_tok; // return ERROR
	}

	// if the reason we have stoped is because we have reached the firstToken - return it (and go back)
	if (currentNode->tokensArray[currentIndex].kind == firstToken)
	{
		while (stepsTaken > 0) // go back
		{
			stepsTaken--;
			back_token();
		}

		return firstToken;
	}
	else // same but the reason we have stoped is beacause we have reached the secondToken - return it (and go back)
	{
		while (stepsTaken > 0) // go back
		{
			stepsTaken--;
			back_token();
		}

		return secondToken;
	}

	//return ERROR_tok; // should be unreachable - here for safety.
}

char* getTokenName(eTOKENS theToken)
{
	switch (theToken)
	{
	case INT_KEYWORD_tok: return "INT_KEYWORD_tok"; break;
		case FLOAT_KEYWORD_tok: return "FLOAT_KEYWORD_tok"; break;
		case VOID_KEYWORD_tok: return "VOID_KEYWORD_tok"; break;
		case IF_KEYWORD_tok: return "IF_KEYWORD_tok"; break;
		case RETURN_KEYWORD_tok: return "RETURN_KEYWORD_tok"; break;
		case ADD_OP_tok: return "ADD_OP_tok"; break;
		case MUL_OP_tok: return "MUL_OP_tok"; break;
		case LOW_OP_tok: return "LOW_OP_tok"; break;
		case LOW_EQ_OP_tok: return "LOW_EQ_OP_tok"; break;
		case EQ_OP_tok: return "EQ_OP_tok"; break;
		case GRT_OP_tok: return "GRT_OP_tok"; break;
		case GRT_EQ_OP_tok: return "GRT_EQ_OP_tok"; break;
		case NOT_EQ_OP_tok: return "NOT_EQ_OP_tok"; break;
		case ASSIGNMENT_OP_tok: return "ASSIGNMENT_OP_tok"; break;
		case COMMA_SEP_tok: return "COMMA_SEP_tok"; break;
		case COLON_SEP_tok: return "COLON_SEP_tok"; break;
		case SEMICOLON_SEP_tok: return "SEMICOLON_SEP_tok"; break;
		case PARENTHESES_LEFT_SEP_tok: return "PARENTHESES_LEFT_SEP_tok"; break;
		case PARENTHESES_RIGHT_SEP_tok: return "PARENTHESES_RIGHT_SEP_tok"; break;
		case BRACKETS_LEFT_SEP_tok: return "BRACKETS_LEFT_SEP_tok"; break;
		case BRACKETS_RIGHT_SEP_tok: return "BRACKETS_RIGHT_SEP_tok"; break;
		case CURLY_BRACES_LEFT_SEP_tok: return "CURLY_BRACES_LEFT_SEP_tok"; break;
		case CURLY_BRACES_RIGHT_SEP_tok: return "CURLY_BRACES_RIGHT_SEP_tok"; break;
		case ID_tok: return "ID_tok"; break;
		case INT_NUM_tok: return "INT_NUM_tok"; break;
		case FLOAT_NUM_tok: return "FLOAT_NUM_tok"; break;
		case EOF_tok: return "EOF_tok"; break;
		case ERROR_tok: return "ERROR_tok"; break;
		default: return NULL; break;
	};
}
