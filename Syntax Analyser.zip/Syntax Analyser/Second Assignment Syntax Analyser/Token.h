#ifndef TOKEN_H
#define TOKEN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern FILE* yyin, * yyout;

FILE* yysynout;  // second stage output file

typedef enum eTOKENS
{
	/*
		Examples of tokens, add/change according to your needs.

		Alternative way to define tokens:
		#define TOKEN_INTEGER 1
		#define TOKEN_IF 2
		...........
	*/

	INT_KEYWORD_tok,
	FLOAT_KEYWORD_tok,
	VOID_KEYWORD_tok,
	IF_KEYWORD_tok,
	RETURN_KEYWORD_tok,
	ADD_OP_tok,
	MUL_OP_tok,
	LOW_OP_tok,
	LOW_EQ_OP_tok,
	EQ_OP_tok,
	GRT_OP_tok,
	GRT_EQ_OP_tok,
	NOT_EQ_OP_tok,
	ASSIGNMENT_OP_tok,
	COMMA_SEP_tok,
	COLON_SEP_tok,
	SEMICOLON_SEP_tok,
	PARENTHESES_LEFT_SEP_tok,
	PARENTHESES_RIGHT_SEP_tok,
	BRACKETS_LEFT_SEP_tok,
	BRACKETS_RIGHT_SEP_tok,
	CURLY_BRACES_LEFT_SEP_tok,
	CURLY_BRACES_RIGHT_SEP_tok,
	ID_tok,
	INT_NUM_tok,
	FLOAT_NUM_tok,
	EOF_tok,
	ERROR_tok

}eTOKENS;

typedef struct Token
{
	eTOKENS kind;
	char* lexeme;
	int lineNumber;
}Token;

typedef struct Node
{
	Token* tokensArray;
	struct Node* prev;
	struct Node* next;
} Node;

void create_and_store_token(eTOKENS kind, char* lexeme, int numOfLine);
Token* next_token();
Token* back_token();
void match(eTOKENS kindToMatch);
Token* lookahead(int numOfSteps);
eTOKENS whatIsComingFirst(eTOKENS firstToken, eTOKENS secondToken);
char* getTokenName(eTOKENS theToken);

#endif