#include "parser.h"

FILE* yysynout;

// Main parser's function - parse
void parse()
{
	parse_PROG(); // parse the program 
	match(EOF_tok); // match EOF - the token we get after the program ends
} 

// Other parsing functions - one for each variable in the grammar
void parse_PROG()
{
	fprintf(yysynout, "Rule(PROG -> GLOBAL_VARS FUNC_PREDEFS FUNC_FULL_DEFS)\n");
	parse_GLOBAL_VARS();
	parse_FUNC_PREDEFS();
	parse_FUNC_FULL_DEFS();
}

void parse_GLOBAL_VARS()
{
	fprintf(yysynout, "Rule(GLOBAL_VARS -> VAR_DEC GLOBAL_VARS')\n");
	parse_VAR_DEC();
	parse_GLOBAL_VARS_tag();
}

void parse_GLOBAL_VARS_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got 'int' or 'float' 
	case INT_KEYWORD_tok: case FLOAT_KEYWORD_tok:

		// look ahead for 2 steps and check whether we have reached '(' or ';' and '['
		if (lookahead(2)->kind == PARENTHESES_LEFT_SEP_tok)
		{
			// reached '(' - stop parsing this variable
			fprintf(yysynout, "Rule(GLOBAL_VARS' -> epsilon)\n");
			back_token();
		}
		else
		{
			// continue with the parsing of this variable
			fprintf(yysynout, "Rule(GLOBAL_VARS' -> VAR_DEC GLOBAL_VARS')\n");
			back_token();
			parse_VAR_DEC();
			parse_GLOBAL_VARS_tag();
		}
		break;

		// Epsilon rule
	case VOID_KEYWORD_tok: fprintf(yysynout, "Rule(GLOBAL_VARS' -> epsilon)\n"); back_token(); break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' or '%s' or '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(INT_KEYWORD_tok), getTokenName(FLOAT_KEYWORD_tok), getTokenName(VOID_KEYWORD_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != VOID_KEYWORD_tok && t->kind != INT_KEYWORD_tok && t->kind != FLOAT_KEYWORD_tok)
		{
			t = next_token();
		}
		back_token();
		break;
	};
}

void parse_VAR_DEC()
{
	fprintf(yysynout, "Rule(VAR_DEC -> TYPR id VAR_DEC')\n");
	parse_TYPE();
	match(ID_tok);
	parse_VAR_DEC_tag();
}

void parse_VAR_DEC_tag() 
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got ';' 
	case SEMICOLON_SEP_tok: fprintf(yysynout, "Rule(VAR_DEC' -> ;)\n"); break;
	
		// Got '['
	case BRACKETS_LEFT_SEP_tok:
		fprintf(yysynout, "Rule(VAR_DEC' -> [DIM_SIZES];)\n");
		parse_DIM_SIZES();
		match(BRACKETS_RIGHT_SEP_tok);
		match(SEMICOLON_SEP_tok);
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' or '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(INT_KEYWORD_tok), getTokenName(FLOAT_KEYWORD_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != VOID_KEYWORD_tok && t->kind != INT_KEYWORD_tok && t->kind != FLOAT_KEYWORD_tok
			&& t->kind != ID_tok && t->kind != CURLY_BRACES_LEFT_SEP_tok && t->kind != IF_KEYWORD_tok
			&& t->kind != RETURN_KEYWORD_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}
		back_token();
		break;
	};
}

void parse_TYPE()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got 'int' 
	case INT_KEYWORD_tok: fprintf(yysynout, "Rule(TYPE -> int)\n"); break;

		// Got 'float'
	case FLOAT_KEYWORD_tok:
		fprintf(yysynout, "Rule(TYPE -> float)\n");
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' or '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(INT_KEYWORD_tok), getTokenName(FLOAT_KEYWORD_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		do
		{
			t = next_token();
		} while (t->kind != ID_tok && t->kind != EOF_tok);

		back_token();
		
		break;
	};
}

void parse_DIM_SIZES()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got an integer number 
	case INT_NUM_tok: fprintf(yysynout, "Rule(DIM_SIZES -> int_num DIM_SIZES')\n");
					  parse_DIM_SIZES_tag();
					  break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(INT_NUM_tok), t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != BRACKETS_RIGHT_SEP_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token(); // NO NEED TO BACK ONE STEP ? - no variable has the Token ']' in its FIRST
		break;
	};
}

void parse_DIM_SIZES_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got a ','
	case COMMA_SEP_tok:
		fprintf(yysynout, "Rule(DIM_SIZES_tag -> , DIM_SIZES)\n"); 
		parse_DIM_SIZES();
		break;

		// Epsilon rule
	case BRACKETS_RIGHT_SEP_tok: fprintf(yysynout, "Rule(DIM_SIZES_tag -> epsilon)\n"); back_token(); break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(COMMA_SEP_tok), t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != BRACKETS_RIGHT_SEP_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}
		back_token(); // NO NEED TO BACK ONE STEP ? - no variable has the Token ']' in its FIRST
		break;
	};
}

void parse_FUNC_PREDEFS()
{
	fprintf(yysynout, "Rule(FUNC_PREDEFS -> FUNC_PROTOTYPE ; FUNC_PREDEFS')\n");
	parse_FUNC_PROTOTYPE();
	match(SEMICOLON_SEP_tok);
	parse_FUNC_PREDEFS_tag();
}

void parse_FUNC_PREDEFS_tag()
{
	Token* t = next_token(); // get the next Token
	eTOKENS firstToComeToken;

	switch (t->kind) {
		// Got 'int' or 'float' or 'void'
	case INT_KEYWORD_tok: case FLOAT_KEYWORD_tok: case VOID_KEYWORD_tok:

		// what is coming first? ';' or '{'
		firstToComeToken = whatIsComingFirst(SEMICOLON_SEP_tok, CURLY_BRACES_LEFT_SEP_tok);

		// if we will encounter ';' first so it is probably another predef
		if (firstToComeToken == SEMICOLON_SEP_tok)
		{
			fprintf(yysynout, "Rule(FUNC_PREDEFS' -> FUNC_PROTOTYPE ; FUNC_PREDEFS')\n");
			back_token();
			parse_FUNC_PROTOTYPE();
			match(SEMICOLON_SEP_tok);
			parse_FUNC_PREDEFS_tag();
		}
		else if (firstToComeToken == CURLY_BRACES_LEFT_SEP_tok)
		{
			// then we need to start with the parsing of the full defs
			fprintf(yysynout, "Rule(FUNC_PREDEFS' -> epsilon)\n");
			back_token();
		}
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' or '%s' or '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(INT_KEYWORD_tok), getTokenName(FLOAT_KEYWORD_tok), getTokenName(VOID_KEYWORD_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != VOID_KEYWORD_tok && t->kind != INT_KEYWORD_tok 
			&& t->kind != FLOAT_KEYWORD_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}
		back_token();
		break;
	};
}

void parse_FUNC_PROTOTYPE()
{
	fprintf(yysynout, "Rule(FUNC_PROTOTYPE -> RETURNED_TYPE id (PARAMS))\n");
	parse_RETURNED_TYPE();
	match(ID_tok);
	match(PARENTHESES_LEFT_SEP_tok);
	parse_PARAMS();
	match(PARENTHESES_RIGHT_SEP_tok);
}

void parse_FUNC_FULL_DEFS()
{
	fprintf(yysynout, "Rule(FUNC_FULL_DEFS -> FUNC_WITH_BODY FUNC_FULL_DEFS')\n");
	parse_FUNC_WITH_BODY();
	parse_FUNC_FULL_DEFS_tag();
}

void parse_FUNC_FULL_DEFS_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got 'int' or 'float' or 'void' 
	case INT_KEYWORD_tok: case FLOAT_KEYWORD_tok: case VOID_KEYWORD_tok:
		fprintf(yysynout, "Rule(FUNC_FULL_DEFS' -> FUNC_FULL_DEFS)\n");
		back_token();
		parse_FUNC_FULL_DEFS();
		break;

		// Epsilon rule
	case EOF_tok:
		fprintf(yysynout, "Rule(FUNC_FULL_DEFS' -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' or '%s' or '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(INT_KEYWORD_tok), getTokenName(FLOAT_KEYWORD_tok), getTokenName(VOID_KEYWORD_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != EOF_tok)
		{
			t = next_token();
		}
		back_token(); // NO NEED FOR THE BACK_TOKEN CALL? 
		break;
	};
}

void parse_FUNC_WITH_BODY()
{
	fprintf(yysynout, "Rule(FUNC_WITH_BODY -> FUNC_PROTOTYPE COMP_STMT)\n");
	parse_FUNC_PROTOTYPE();
	parse_COMP_STMT();
}

void parse_RETURNED_TYPE()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got 'int' or 'float'
	case INT_KEYWORD_tok: case FLOAT_KEYWORD_tok:
		fprintf(yysynout, "Rule(RETURNED_TYPE -> TYPE)\n");
		back_token();
		parse_TYPE();
		break;

		// Got void
	case VOID_KEYWORD_tok:
		fprintf(yysynout, "Rule(RETURNED_TYPE -> void)\n");
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' or '%s' or '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(INT_KEYWORD_tok), getTokenName(FLOAT_KEYWORD_tok), getTokenName(VOID_KEYWORD_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != ID_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}
		back_token();
		break;
	};
}

void parse_PARAMS()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got 'int' or 'float'
	case INT_KEYWORD_tok: case FLOAT_KEYWORD_tok:
		fprintf(yysynout, "Rule(PARAMS -> PARAM_LIST)\n");
		back_token();
		parse_PARAM_LIST();
		break;

		// Epsilon rule
	case PARENTHESES_RIGHT_SEP_tok:
		fprintf(yysynout, "Rule(PARAMS -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' or '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(INT_KEYWORD_tok), getTokenName(FLOAT_KEYWORD_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != PARENTHESES_RIGHT_SEP_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_PARAM_LIST()
{
	fprintf(yysynout, "Rule(PARAMS_LIST -> PARAM PARAM_LIST')\n");
	parse_PARAM();
	parse_PARAM_LIST_tag();
}

void parse_PARAM_LIST_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got ','
	case COMMA_SEP_tok:
		fprintf(yysynout, "Rule(PARAM_LIST' -> , PARAM PARAM_LIST')\n");
		parse_PARAM();
		parse_PARAM_LIST_tag();
		break;

		// Epsilon rule
	case PARENTHESES_RIGHT_SEP_tok:
		fprintf(yysynout, "Rule(PARAM_LIST' -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(COMMA_SEP_tok), t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != PARENTHESES_RIGHT_SEP_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_PARAM()
{
	fprintf(yysynout, "Rule(PARAM -> TYPE id PARAM')\n");
	parse_TYPE();
	match(ID_tok);
	parse_PARAM_tag();
}

void parse_PARAM_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got '['
	case BRACKETS_LEFT_SEP_tok:
		fprintf(yysynout, "Rule(PARAM' -> [DIM_SIZES])\n");
		parse_DIM_SIZES();
		match(BRACKETS_RIGHT_SEP_tok);
		break;

		// Epsilon rule
	case PARENTHESES_RIGHT_SEP_tok: case COMMA_SEP_tok:
		fprintf(yysynout, "Rule(PARAM' -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(COMMA_SEP_tok), t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != PARENTHESES_RIGHT_SEP_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_COMP_STMT()
{
	fprintf(yysynout, "Rule(COMP_STMT -> { VAR_DEC_LIST STMT_LIST })\n");
	match(CURLY_BRACES_LEFT_SEP_tok);
	parse_VAR_DEC_LIST();
	parse_STMT_LIST();
	match(CURLY_BRACES_RIGHT_SEP_tok);
}

void parse_VAR_DEC_LIST()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got 'int' or 'float'
	case INT_KEYWORD_tok: case FLOAT_KEYWORD_tok:
		fprintf(yysynout, "Rule(VAR_DEC_LIST -> VAR_DEC VAR_DEC_LIST)\n");
		back_token();
		parse_VAR_DEC();
		parse_VAR_DEC_LIST();
		break;

		// Epsilon rule
	case ID_tok: case CURLY_BRACES_LEFT_SEP_tok: case IF_KEYWORD_tok: case RETURN_KEYWORD_tok:
		fprintf(yysynout, "Rule(VAR_DEC_LIST -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s', '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(INT_KEYWORD_tok), getTokenName(FLOAT_KEYWORD_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != ID_tok && t->kind != CURLY_BRACES_LEFT_SEP_tok
			&& t->kind != IF_KEYWORD_tok && t->kind != RETURN_KEYWORD_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_STMT_LIST()
{
	fprintf(yysynout, "Rule(STMT_LIST -> STMT STMT_LIST')\n");
	parse_STMT();
	parse_STMT_LIST_tag();
}

void parse_STMT_LIST_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got ';'
	case SEMICOLON_SEP_tok:
		fprintf(yysynout, "Rule(STMT_LIST' -> ; STMT STMT_LIST')\n");
		parse_STMT();
		parse_STMT_LIST_tag();
		break;

		// Epsilon rule
	case CURLY_BRACES_RIGHT_SEP_tok:
		fprintf(yysynout, "Rule(STMT_LIST' -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(SEMICOLON_SEP_tok), t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != CURLY_BRACES_RIGHT_SEP_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_STMT()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got 'id'
	case ID_tok:
		fprintf(yysynout, "Rule(STMT -> id STMT')\n");
		parse_STMT_tag();
		break;

		// Got '{'
	case CURLY_BRACES_LEFT_SEP_tok:
		fprintf(yysynout, "Rule(STMT -> COMP_STMT)\n");
		back_token();
		parse_COMP_STMT();
		break;

		// Got 'if'
	case IF_KEYWORD_tok:
		fprintf(yysynout, "Rule(STMT -> IF_STMT)\n");
		back_token();
		parse_IF_STMT();
		break;

		// Got 'return'
	case RETURN_KEYWORD_tok:
		fprintf(yysynout, "Rule(STMT -> RETURN_STMT)\n");
		back_token();
		parse_RETURN_STMT();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s', '%s', '%s', '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(ID_tok)
		, getTokenName(CURLY_BRACES_LEFT_SEP_tok)
		, getTokenName(IF_KEYWORD_tok)
		, getTokenName(RETURN_KEYWORD_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != SEMICOLON_SEP_tok && t->kind != CURLY_BRACES_RIGHT_SEP_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_STMT_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got '[' or '='
	case BRACKETS_LEFT_SEP_tok: case ASSIGNMENT_OP_tok:
		fprintf(yysynout, "Rule(STMT' -> VAR' = EXPR)\n");
		back_token();
		parse_VAR_tag();
		match(ASSIGNMENT_OP_tok);
		parse_EXPR();
		break;

		// Got '('
	case PARENTHESES_LEFT_SEP_tok:
		fprintf(yysynout, "Rule(STMT' -> (ARGS))\n");
		parse_ARGS();
		match(PARENTHESES_RIGHT_SEP_tok);
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s', '%s', '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(BRACKETS_LEFT_SEP_tok)
		, getTokenName(ASSIGNMENT_OP_tok)
		, getTokenName(PARENTHESES_LEFT_SEP_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != SEMICOLON_SEP_tok && t->kind != CURLY_BRACES_RIGHT_SEP_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_IF_STMT()
{
	fprintf(yysynout, "Rule(IF_STMT -> if (CONDITION) STMT)\n");
	match(IF_KEYWORD_tok);
	match(PARENTHESES_LEFT_SEP_tok);
	parse_CONDITION();
	match(PARENTHESES_RIGHT_SEP_tok);
	parse_STMT();
}

void parse_CALL()
{
	fprintf(yysynout, "Rule(CALL -> id (ARGS))\n");
	match(ID_tok);
	match(PARENTHESES_LEFT_SEP_tok);
	parse_ARGS();
	match(PARENTHESES_RIGHT_SEP_tok);
}

void parse_ARGS()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got 'int_num' or 'float_num' or '(' or 'id'
	case INT_NUM_tok: case FLOAT_NUM_tok: case PARENTHESES_LEFT_SEP_tok: case ID_tok:
		back_token();
		fprintf(yysynout, "Rule(ARGS -> ARG_LIST)\n");
		parse_ARG_LIST();
		break;
	

		// Epsilon rule
	case PARENTHESES_RIGHT_SEP_tok:
		fprintf(yysynout, "Rule(ARGS -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s', '%s', '%s', '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(INT_NUM_tok)
		, getTokenName(FLOAT_NUM_tok)
		, getTokenName(PARENTHESES_LEFT_SEP_tok)
		, getTokenName(ID_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != PARENTHESES_RIGHT_SEP_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_ARG_LIST()
{
	fprintf(yysynout, "Rule(ARG_LIST -> EXPR ARG_LIST')\n");
	parse_EXPR();
	parse_ARG_LIST_tag();
}

void parse_ARG_LIST_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got ','
	case COMMA_SEP_tok:
		fprintf(yysynout, "Rule(ARG_LIST' -> , EXPR ARG_LIST')\n");
		parse_EXPR();
		parse_ARG_LIST_tag();
		break;

		// Epsilon rule
	case PARENTHESES_RIGHT_SEP_tok:
		fprintf(yysynout, "Rule(ARG_LIST' -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(COMMA_SEP_tok), t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != PARENTHESES_RIGHT_SEP_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_RETURN_STMT()
{
	fprintf(yysynout, "Rule(RETURN_STMT -> return RETURN_STMT')\n");
	match(RETURN_KEYWORD_tok);
	parse_RETURN_STMT_tag();
}

void parse_RETURN_STMT_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got 'int_num' or 'float_num' or '(' or 'id'
	case INT_NUM_tok: case FLOAT_NUM_tok: case PARENTHESES_LEFT_SEP_tok: case ID_tok:
		fprintf(yysynout, "Rule(RETURN_STMT' -> EXPR)\n");
		back_token();
		parse_EXPR();
		break;

		// Epsilon rule
	case SEMICOLON_SEP_tok: case CURLY_BRACES_RIGHT_SEP_tok:
		fprintf(yysynout, "Rule(RETURN_STMT' -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s', '%s', '%s', '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(INT_NUM_tok)
		, getTokenName(FLOAT_NUM_tok)
		, getTokenName(PARENTHESES_LEFT_SEP_tok)
		, getTokenName(ID_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != SEMICOLON_SEP_tok && t->kind != CURLY_BRACES_RIGHT_SEP_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_VAR()
{
	fprintf(yysynout, "Rule(VAR -> id VAR')\n");
	match(ID_tok);
	parse_VAR_tag();
}

void parse_VAR_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got '['
	case BRACKETS_LEFT_SEP_tok:
		fprintf(yysynout, "Rule(VAR' -> [EXPR_LIST])\n");
		parse_EXPR_LIST();
		match(BRACKETS_RIGHT_SEP_tok);
		break;
		
		// Epsilon rule (OP = {LOW_OP}|{LOW_EQ_OP}|{EQ_OP}|{GRT_OP}|{GRT_EQ_OP}|{NOT_EQ_OP})
	case ASSIGNMENT_OP_tok: case MUL_OP_tok: case ADD_OP_tok: case SEMICOLON_SEP_tok: case CURLY_BRACES_RIGHT_SEP_tok:
	case COMMA_SEP_tok: case PARENTHESES_RIGHT_SEP_tok: case BRACKETS_RIGHT_SEP_tok:
	case LOW_OP_tok: case LOW_EQ_OP_tok: case EQ_OP_tok: case GRT_OP_tok: case GRT_EQ_OP_tok: case NOT_EQ_OP_tok:
		fprintf(yysynout, "Rule(VAR' -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(BRACKETS_LEFT_SEP_tok), t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != ASSIGNMENT_OP_tok && t->kind != MUL_OP_tok
			&& t->kind != ADD_OP_tok && t->kind != SEMICOLON_SEP_tok 
			&& t->kind != CURLY_BRACES_RIGHT_SEP_tok && t->kind != COMMA_SEP_tok 
			&& t->kind != PARENTHESES_RIGHT_SEP_tok && t->kind != BRACKETS_RIGHT_SEP_tok 
			&& t->kind != LOW_OP_tok && t->kind != LOW_EQ_OP_tok
			&& t->kind != EQ_OP_tok && t->kind != GRT_OP_tok
			&& t->kind != GRT_EQ_OP_tok && t->kind != NOT_EQ_OP_tok
			&& t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_EXPR_LIST()
{
	fprintf(yysynout, "Rule(EXPR_LIST -> EXPR EXPR_LIST')\n");
	parse_EXPR();
	parse_EXPR_LIST_tag();
}

void parse_EXPR_LIST_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got ','
	case COMMA_SEP_tok:
		fprintf(yysynout, "Rule(EXPR_LIST' -> , EXPR EXPR_LIST')\n");
		parse_EXPR();
		parse_EXPR_LIST_tag();
		break;

		// Epsilon rule
	case BRACKETS_RIGHT_SEP_tok:
		fprintf(yysynout, "Rule(EXPR_LIST' -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(COMMA_SEP_tok), t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != BRACKETS_RIGHT_SEP_tok && t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_CONDITION()
{
	parse_EXPR();

	Token* t = next_token();

	switch (t->kind)
	{
		// rel_op = {LOW_OP}|{LOW_EQ_OP}|{EQ_OP}|{GRT_OP}|{GRT_EQ_OP}|{NOT_EQ_OP}

	case LOW_OP_tok:
		fprintf(yysynout, "Rule(CONDITION -> EXPR < EXPR)\n");
		break;

	case LOW_EQ_OP_tok:
		fprintf(yysynout, "Rule(CONDITION -> EXPR <= EXPR)\n");
		break;

	case EQ_OP_tok:
		fprintf(yysynout, "Rule(CONDITION -> EXPR == EXPR)\n");
		break;

	case GRT_OP_tok:
		fprintf(yysynout, "Rule(CONDITION -> EXPR > EXPR)\n");
		break;

	case GRT_EQ_OP_tok:
		fprintf(yysynout, "Rule(CONDITION -> EXPR >= EXPR)\n");
		break;

	case NOT_EQ_OP_tok:
		fprintf(yysynout, "Rule(CONDITION -> EXPR != EXPR)\n");
		break;

	default:fprintf(yysynout, "Expected token of type '%s', '%s', '%s', '%s', '%s', '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(LOW_OP_tok)
		, getTokenName(LOW_EQ_OP_tok)
		, getTokenName(EQ_OP_tok)
		, getTokenName(GRT_OP_tok)
		, getTokenName(GRT_EQ_OP_tok)
		, getTokenName(NOT_EQ_OP_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		// search for the first of EXPR
		while (t->kind != INT_NUM_tok
			&& t->kind != FLOAT_NUM_tok 
			&& t->kind != PARENTHESES_LEFT_SEP_tok
			&& t->kind != ID_tok 
			&& t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};

	parse_EXPR();
}

void parse_EXPR()
{
	fprintf(yysynout, "Rule(EXPR -> TERM EXPR')\n");
	parse_TERM();
	parse_EXPR_tag();
}

void parse_EXPR_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got '+'
	case ADD_OP_tok:
		fprintf(yysynout, "Rule(EXPR' -> + TERM EXPR')\n");
		parse_TERM();
		parse_EXPR_tag();
		break;

		// Epsilon rule (OP = {LOW_OP}|{LOW_EQ_OP}|{EQ_OP}|{GRT_OP}|{GRT_EQ_OP}|{NOT_EQ_OP})
	case SEMICOLON_SEP_tok: case CURLY_BRACES_RIGHT_SEP_tok:
	case COMMA_SEP_tok: case PARENTHESES_RIGHT_SEP_tok: case BRACKETS_RIGHT_SEP_tok:
	case LOW_OP_tok: case LOW_EQ_OP_tok: case EQ_OP_tok: case GRT_OP_tok: case GRT_EQ_OP_tok: case NOT_EQ_OP_tok:
		fprintf(yysynout, "Rule(EXPR' -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(ADD_OP_tok), t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != SEMICOLON_SEP_tok
			&& t->kind != CURLY_BRACES_RIGHT_SEP_tok && t->kind != COMMA_SEP_tok
			&& t->kind != PARENTHESES_RIGHT_SEP_tok && t->kind != BRACKETS_RIGHT_SEP_tok
			&& t->kind != LOW_OP_tok && t->kind != LOW_EQ_OP_tok
			&& t->kind != EQ_OP_tok && t->kind != GRT_OP_tok
			&& t->kind != GRT_EQ_OP_tok && t->kind != NOT_EQ_OP_tok
			&& t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_TERM()
{
	fprintf(yysynout, "Rule(TERM -> FACTOR TERM')\n");
	parse_FACTOR();
	parse_TERM_tag();
}

void parse_TERM_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got '*'
	case MUL_OP_tok:
		fprintf(yysynout, "Rule(TERM' -> * FACTOR TERM')\n");
		parse_FACTOR();
		parse_TERM_tag();
		break;

		// Epsilon rule (OP = {LOW_OP}|{LOW_EQ_OP}|{EQ_OP}|{GRT_OP}|{GRT_EQ_OP}|{NOT_EQ_OP})
	case ADD_OP_tok: case SEMICOLON_SEP_tok: case CURLY_BRACES_RIGHT_SEP_tok:
	case COMMA_SEP_tok: case PARENTHESES_RIGHT_SEP_tok: case BRACKETS_RIGHT_SEP_tok:
	case LOW_OP_tok: case LOW_EQ_OP_tok: case EQ_OP_tok: case GRT_OP_tok: case GRT_EQ_OP_tok: case NOT_EQ_OP_tok:
		fprintf(yysynout, "Rule(TERM' -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(ADD_OP_tok), t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != ADD_OP_tok && t->kind != SEMICOLON_SEP_tok
			&& t->kind != CURLY_BRACES_RIGHT_SEP_tok && t->kind != COMMA_SEP_tok
			&& t->kind != PARENTHESES_RIGHT_SEP_tok && t->kind != BRACKETS_RIGHT_SEP_tok
			&& t->kind != LOW_OP_tok && t->kind != LOW_EQ_OP_tok
			&& t->kind != EQ_OP_tok && t->kind != GRT_OP_tok
			&& t->kind != GRT_EQ_OP_tok && t->kind != NOT_EQ_OP_tok
			&& t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_FACTOR()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got 'int_num'
	case INT_NUM_tok:
		fprintf(yysynout, "Rule(FACTOR -> int_num)\n");
		break;

		// Got 'float_num'
	case FLOAT_NUM_tok:
		fprintf(yysynout, "Rule(FACTOR -> float_num)\n");
		break;

		// Got '('
	case PARENTHESES_LEFT_SEP_tok:
		fprintf(yysynout, "Rule(FACTOR -> (EXPR))\n");
		parse_EXPR();
		match(PARENTHESES_RIGHT_SEP_tok);
		break;

		// Got 'id'
	case ID_tok:
		fprintf(yysynout, "Rule(FACTOR -> id FACTOR')\n");
		parse_FACTOR_tag();
		break;

		// Epsilon rule (OP = {LOW_OP}|{LOW_EQ_OP}|{EQ_OP}|{GRT_OP}|{GRT_EQ_OP}|{NOT_EQ_OP})
	case MUL_OP_tok: case ADD_OP_tok: case SEMICOLON_SEP_tok: case CURLY_BRACES_RIGHT_SEP_tok:
	case COMMA_SEP_tok: case PARENTHESES_RIGHT_SEP_tok: case BRACKETS_RIGHT_SEP_tok:
	case LOW_OP_tok: case LOW_EQ_OP_tok: case EQ_OP_tok: case GRT_OP_tok: case GRT_EQ_OP_tok: case NOT_EQ_OP_tok:
		fprintf(yysynout, "Rule(VAR' -> epsilon)\n");
		back_token();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s', '%s', '%s', '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(INT_NUM_tok)
		, getTokenName(FLOAT_NUM_tok)
		, getTokenName(PARENTHESES_LEFT_SEP_tok)
		, getTokenName(ID_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != MUL_OP_tok
			&& t->kind != ADD_OP_tok && t->kind != SEMICOLON_SEP_tok
			&& t->kind != CURLY_BRACES_RIGHT_SEP_tok && t->kind != COMMA_SEP_tok
			&& t->kind != PARENTHESES_RIGHT_SEP_tok && t->kind != BRACKETS_RIGHT_SEP_tok
			&& t->kind != LOW_OP_tok && t->kind != LOW_EQ_OP_tok
			&& t->kind != EQ_OP_tok && t->kind != GRT_OP_tok
			&& t->kind != GRT_EQ_OP_tok && t->kind != NOT_EQ_OP_tok
			&& t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}

void parse_FACTOR_tag()
{
	Token* t = next_token(); // get the next Token

	switch (t->kind) {
		// Got '('
	case PARENTHESES_LEFT_SEP_tok:
		fprintf(yysynout, "Rule(FACTOR' -> (ARGS))\n");
		parse_ARGS();
		match(PARENTHESES_RIGHT_SEP_tok);
		break;

		// Got '['
	case BRACKETS_LEFT_SEP_tok:
		fprintf(yysynout, "Rule(FACTOR' -> VAR')\n");
		back_token();
		parse_VAR_tag();
		break;

		// Epsilon rule (OP = {LOW_OP}|{LOW_EQ_OP}|{EQ_OP}|{GRT_OP}|{GRT_EQ_OP}|{NOT_EQ_OP})
	case MUL_OP_tok: case ADD_OP_tok: case SEMICOLON_SEP_tok: case CURLY_BRACES_RIGHT_SEP_tok:
	case COMMA_SEP_tok: case PARENTHESES_RIGHT_SEP_tok: case BRACKETS_RIGHT_SEP_tok:
	case LOW_OP_tok: case LOW_EQ_OP_tok: case EQ_OP_tok: case GRT_OP_tok: case GRT_EQ_OP_tok: case NOT_EQ_OP_tok:
		fprintf(yysynout, "Rule(FACTOR' -> VAR')\n");
		back_token();
		parse_VAR_tag();
		break;

		// Error - print and try to find a safe spot
	default: fprintf(yysynout, "Expected token of type '%s', '%s' at line: %d,\nActual token of type '%s', lexeme: '%s'.\n"
		, getTokenName(PARENTHESES_LEFT_SEP_tok)
		, getTokenName(BRACKETS_LEFT_SEP_tok)
		, t->lineNumber, getTokenName(t->kind), t->lexeme);

		while (t->kind != MUL_OP_tok
			&& t->kind != ADD_OP_tok && t->kind != SEMICOLON_SEP_tok
			&& t->kind != CURLY_BRACES_RIGHT_SEP_tok && t->kind != COMMA_SEP_tok
			&& t->kind != PARENTHESES_RIGHT_SEP_tok && t->kind != BRACKETS_RIGHT_SEP_tok
			&& t->kind != LOW_OP_tok && t->kind != LOW_EQ_OP_tok
			&& t->kind != EQ_OP_tok && t->kind != GRT_OP_tok
			&& t->kind != GRT_EQ_OP_tok && t->kind != NOT_EQ_OP_tok
			&& t->kind != EOF_tok)
		{
			t = next_token();
		}

		back_token();
		break;
	};
}
