#pragma once

#include "Token.h"
#include <string.h>

// Main parser's function - parse
void parse();

// Other parsing functions - one for each variable in the grammar
void parse_PROG();
void parse_GLOBAL_VARS();
void parse_GLOBAL_VARS_tag();
void parse_VAR_DEC();
void parse_VAR_DEC_tag();
void parse_TYPE();
void parse_DIM_SIZES();
void parse_DIM_SIZES_tag();
void parse_FUNC_PREDEFS();
void parse_FUNC_PREDEFS_tag();
void parse_FUNC_PROTOTYPE();
void parse_FUNC_FULL_DEFS();
void parse_FUNC_FULL_DEFS_tag();
void parse_FUNC_WITH_BODY();
void parse_RETURNED_TYPE();
void parse_PARAMS();
void parse_PARAM_LIST();
void parse_PARAM_LIST_tag();
void parse_PARAM();
void parse_PARAM_tag();
void parse_COMP_STMT();
void parse_VAR_DEC_LIST();
void parse_STMT_LIST();
void parse_STMT_LIST_tag();
void parse_STMT();
void parse_STMT_tag();
void parse_IF_STMT();
void parse_CALL();
void parse_ARGS();
void parse_ARG_LIST();
void parse_ARG_LIST_tag();
void parse_RETURN_STMT();
void parse_RETURN_STMT_tag();
void parse_VAR();
void parse_VAR_tag();
void parse_EXPR_LIST();
void parse_EXPR_LIST_tag();
void parse_CONDITION();
void parse_EXPR();
void parse_EXPR_tag();
void parse_TERM();
void parse_TERM_tag();
void parse_FACTOR();
void parse_FACTOR_tag();